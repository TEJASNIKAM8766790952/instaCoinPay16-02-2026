module.exports = {
  BTC: "btc",
  ETH: "eth",
  BNB: "bnb",
  SOL: "sol",
  XRP: "xrp",
  DOGE: "doge",
  LTC: "ltc",
  TRX: "trx",
  "USDT-BNB": "usdtBnb",
  "USDT-TRON": "usdtTron",
};